<!DOCTYPE html>
<html>
<head>
  <title>Timings</title>
</head>
<body>
  <h1>Timings</h1>
  <?php
    $currentTime = date("H");
    if ($currentTime >= 0 && $currentTime < 24) {
      echo "Good Morning!";
    } 
    else
     {
      echo "Good Afternoon!";
    }
  ?>
</body>
</html>
