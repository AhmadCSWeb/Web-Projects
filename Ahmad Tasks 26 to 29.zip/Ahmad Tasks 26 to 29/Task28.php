<!DOCTYPE html>
<html>
<head>
  <title>Name</title>
</head>
<body>
  <h1>Name in PHP</h1>
  <?php
    $name = "Muhammad Ahmad";
    echo "My name is: '$name'";
  ?>
</body>
</html>