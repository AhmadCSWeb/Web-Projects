<h1>Main Page</h1>
<a href="{{route('create')}}">Add Items</a>
<table class="table">

      <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Price</th>
        <th colspan="2">Action</th>
      </tr>


      @foreach($ProductList as $i)
      <tr>
            <th scope="row">{{$i->id}}</th>
            <td>{{$i->name}}</td>
            <td>{{$i->price}}</td>
            <td>{{$i->created_at}}</td>
            <td>{{$i->updated_at}}</td>
            <td><a href="{{url('/edit/'.$i->id)}}">Edit</a></td>
            <td><a href="{{url('/delete/'.$i->id)}}">Delete</a></td>

          </tr>
      @endforeach
  </table>
