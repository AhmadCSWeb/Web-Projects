<h1>Form</h1>
<form action="{{route('update')}}">
    <input type="number" value="{{$itemsdata->id}}" name="id" hidden>
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="{{$itemsdata->name}}">
    <label for="price">Price</label>
    <input type="text" name="price" id="price" value="{{$itemsdata->price}}">
    <button type="submit">Submit</button>

</form>
