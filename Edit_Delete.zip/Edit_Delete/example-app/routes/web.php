<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ItemsController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
Route::get('/',[ItemsController::class,'index'])->name('index');
Route::get('/create',[ItemsController::class,'create'])->name('create');
Route::get('/store',[ItemsController::class,'store'])->name('store');
Route::get('/update',[ItemsController::class,'update'])->name('update');
Route::get('/edit/{id}',[ItemsController::class,'edit'])->name('edit');
Route::get('/delete/{id}',[ItemsController::class,'delete'])->name('delete');


