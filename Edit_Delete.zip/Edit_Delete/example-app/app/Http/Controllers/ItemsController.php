<?php

namespace App\Http\Controllers;

use App\Models\Items;
use Illuminate\Http\Request;

class ItemsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data['ProductList']=Items::all();
        return view('products.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('products.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data=new Items;
        $data->name=$request->name;
        $data->price=$request->price;

         $data->save();
         return redirect('/');
    }

    /**
     * Display the specified resource.
     */
    public function show(Items $items)
    {

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($id)
    {
        $data['itemsdata']=Items::find($id);
        return view('products.edit',$data);

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request)
    {

        $id=$request->id;
        $data=Items::find($id);
        $data->name=$request->name;
         $data->price=$request->price;
           $data->save();
         return redirect('/');

    }

    /**
     * Remove the specified resource from storage.
     */
    public function delete($id)
    {
        $data=Items::find($id);
        $data->delete();
        return redirect('/');
    }
}
