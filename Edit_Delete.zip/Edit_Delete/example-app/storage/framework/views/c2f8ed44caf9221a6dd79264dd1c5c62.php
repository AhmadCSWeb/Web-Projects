<h1>Form</h1>
<form action="<?php echo e(route('update')); ?>">
    <input type="number" value="<?php echo e($itemsdata->id); ?>" name="id" hidden>
    <label for="name">Name</label>
    <input type="text" name="name" id="name" value="<?php echo e($itemsdata->name); ?>">
    <label for="price">Price</label>
    <input type="text" name="price" id="price" value="<?php echo e($itemsdata->price); ?>">
    <button type="submit">Submit</button>

</form>
<?php /**PATH C:\Users\PC12\Desktop\Edit_Delete\example-app\resources\views/products/edit.blade.php ENDPATH**/ ?>