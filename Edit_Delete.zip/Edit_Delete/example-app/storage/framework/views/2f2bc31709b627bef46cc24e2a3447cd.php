<h1>Main Page</h1>
<a href="<?php echo e(route('create')); ?>">Add Items</a>
<table class="table">

      <tr>
        <th scope="col">#</th>
        <th scope="col">Name</th>
        <th scope="col">Price</th>
        <th colspan="2">Action</th>
      </tr>


      <?php $__currentLoopData = $ProductList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
            <th scope="row"><?php echo e($i->id); ?></th>
            <td><?php echo e($i->name); ?></td>
            <td><?php echo e($i->price); ?></td>
            <td><?php echo e($i->created_at); ?></td>
            <td><?php echo e($i->updated_at); ?></td>
            <td><a href="<?php echo e(url('/edit/'.$i->id)); ?>">Edit</a></td>
            <td><a href="<?php echo e(url('/delete/'.$i->id)); ?>">Delete</a></td>

          </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
<?php /**PATH C:\Users\PC12\Desktop\Edit_Delete\example-app\resources\views/products/index.blade.php ENDPATH**/ ?>