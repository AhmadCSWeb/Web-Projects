<h1>Form</h1>
<form action="<?php echo e(route('store')); ?>">
    <label for="name">Name</label>
    <input type="text" name="name" id="name">
    <label for="price">Price</label>
    <input type="text" name="price" id="price">
    <button type="submit">Submit</button>

</form>
<?php /**PATH C:\Users\PC12\Desktop\Edit_Delete\example-app\resources\views/products/create.blade.php ENDPATH**/ ?>