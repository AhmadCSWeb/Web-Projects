<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP CRUD</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

</head>
<body>
    

<div class="container my-5">
    <h1>Our Clients</h1>
    <a href="create.php" class="btn btn-outline-success">Add New</a>

    <table class="table table-hover table-light my-3">
        <thead>
            <tr>
            <th>ID</th>
            <th>Client Name</th>
            <th>Email</th>
            <th>Phone #</th>
            <th>Address</th>
            <th>Action</th>
            </tr>
        </thead>

        <tbody>


        <?php

            // Make Coonection With DataBase
            $servername="localhost";
            $username="root";
            $password="";
            $database="php_crud";

            $connection = new mysqli($servername, $username, $password, $database);

            if($connection->connect_error){
                die("Connection Failed: " . $connection->connect_error);
            }

            // Select Query for Data
            $sql= "SELECT * FROM clients";
            $result = $connection->query($sql);

            if(!$result){
                die("Invalid Query: " . $connection->error );
            }

            // Fetch All Data from Table
            while($row = $result->fetch_assoc()){
                echo "
                <tr>
                    <th>$row[id]</th>
                    <td>$row[name]</td>
                    <td>$row[email]</td>
                    <td>$row[phone]</td>
                    <td>$row[address]</td>
                    <td>
                        <a href='edit.php?id=$row[id]' class='btn btn-sm btn-success'>Edit</a>
                        <a href='delete.php?id=$row[id]' class='btn btn-sm btn-danger'>Delete</a>
                    </td>
                </tr>
                ";
            }

        ?>

        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

</body>
</html>