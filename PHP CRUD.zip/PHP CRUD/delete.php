<?php
if (isset($_GET['id'])) {

    $id = $_GET["id"];
    // Make Connection With DataBase
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "php_crud";

    $connection = new mysqli($servername, $username, $password, $database);

    if ($connection->connect_error) {
        die("Connection Failed: " . $connection->connect_error);
    }

    // Delete Query for Data
    $sql = "DELETE FROM clients WHERE id=$id";
    $result = $connection->query($sql);

    header("Location: read.php");
    exit;
}
?>
