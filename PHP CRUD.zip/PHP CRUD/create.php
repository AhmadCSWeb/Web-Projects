<?php
$page="Create";
// Make Coonection With DataBase
$servername="localhost";
$username="root";
$password="";
$database="php_crud";

$connection = new mysqli($servername, $username, $password, $database);

if($connection->connect_error){
    die("Connection Failed: " . $connection->connect_error);
}



$name="";
$email="";
$phone="";
$address="";

$errorMessage="";

// When we hit to Submit Button
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $name= $_POST['name'];
    $email= $_POST['email'];
    $phone= $_POST['phone'];
    $address= $_POST['address'];


do{
      if ( empty($name) || empty($email) || empty($phone) || empty($address) ){
        
        $errorMessage= "All the fields are Required";
        break;
      }

      // Insert Query for Data
          $sql= "INSERT INTO clients (name, email, phone, address) VALUES
          ('$name', '$email', '$phone', '$address')";
          $result = $connection->query($sql);

          if(!$result){
              $errorMessage="Invalid Query: " . $connection->error;
              break;
          }

          header( "Location: read.php");
          exit;
}while(false);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADD CLIENT</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

</head>
<body>
    

  <div class="container">

    <?php
    
    if( !empty($errorMessage) ){

      echo "
      <div class='alert alert-warning alert-dismissible fade show' role='alert'>
      <strong>$errorMessage</strong>
      <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
    </div>
      ";

    }


    ?>

    <form method="post">
      <div class="row g-3">

          <div class="col-12">
            <h2> <?php  if($page="Create"){ echo "Add Client"; } ?> </h2>
          </div>

          <div class="col-12">
              <label for="name" class="form-label">Name</label>
              <input type="text" class="form-control" id="name" name="name" value="<?php echo $name; ?>">
          </div>

          <div class="col-12">
              <label for="email" class="form-label">Email</label>
              <input type="email" class="form-control" id="email" name="email" value="<?php echo $email; ?>">
          </div>

          <div class="col-12">
              <label for="phone" class="form-label">Phone</label>
              <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo $phone; ?>">
          </div>

          <div class="col-12">
              <label for="address" class="form-label">Address</label>
              <textarea name="address" id="address" class="form-control" rows="5"><?php echo $address; ?></textarea>
          </div>
          
          <div class="col-12">
            <button type="submit" class="btn btn-success me-2">Save</button>
            <a href="read.php" class="btn btn-danger">Cancel</a>
          </div>
          
          <div class="col-6">
            
          </div>
          
      </div>
        
        
        
    </form>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

</body>
</html>