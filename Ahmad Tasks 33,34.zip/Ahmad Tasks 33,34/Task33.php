<!DOCTYPE html>
<html>
<body>
<?php

$count = 1;

do {
    echo $count . "<br>";
    $count++;
} while ($count <= 5);

?>

</body>
</html>
