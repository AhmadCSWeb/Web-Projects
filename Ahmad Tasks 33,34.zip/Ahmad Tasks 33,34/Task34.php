<!DOCTYPE html>
<html>
<body>
<?php
$months = array(
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
);
$valueToDelete = "March";

echo "Before removal:<br>";
print_r($months);


foreach ($months as $key => $value) {
    if ($value == $valueToDelete) {
        unset($months[$key]);
    }
}

echo "<br>After removal:<br>";
print_r($months);

?>


</body>
</html>
