<?php
$string="My name is ahmad";
if($string===strtolower($string)) 
{
 echo "The string is in lowercase";

}
else
{
    echo "Not equals to original string";
}
?>