<?php
echo "<h1>Method1</h1>";
echo "<br>";
$str="My name is Ahmad";
echo strlen($str).": ".$str;;
echo "<br>";
echo "<h1>Method2</h1>";
echo "<br>";
$str2="I'm a student";
function string($str2){
    return strlen($str2);
}
echo string($str2).": ".$str2;
?>