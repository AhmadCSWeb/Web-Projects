<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
echo "<h1>Car Names Sorting w.r.t to their First Characters</h1>";
$cars = array("Volvo", "BMW", "Toyota","Honda","Civic","Ferrari");
sort($cars);
$clength = count($cars);
for($x = 0; $x < $clength; $x++) 
{
echo "$x)".$cars[$x];
echo "<br>";
}
//print_r($sorted);

?>
</body>
</html>